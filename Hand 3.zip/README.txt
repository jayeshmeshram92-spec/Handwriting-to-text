Handwriting to Text — Improved OCR

Open index.html in a modern browser. Upload a handwriting photo, choose OCR language, and click Convert to Text.

Improved processing:
- Optional page-border cropping (8% default)
- Grayscale + contrast enhancement
- Strong black/white mode
- 2x image upscaling
- OCR page-layout choice
- Editable output and paper/font preview

Hindi handwriting OCR can still be imperfect because Tesseract.js is not a handwriting-specific AI model. Clear, straight, high-resolution photos give better results. Internet is required to download Tesseract language models.
